#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/cdev.h>
#include <linux/device.h>
#include <linux/delay.h>
#include <linux/uaccess.h>  
#include <linux/gpio.h>     
#include <linux/interrupt.h>
#include <linux/err.h>
#include <linux/jiffies.h>



MODULE_LICENSE("GPL");


int in[5]={16,17,18,19,20};
int out[4]={2,3,4,5};
int GPIO_irq[5];

// Interrupt handler function. Tha name "button_isr" can be different.
// You may use printk statements for debugging purposes.

//Interrupt handler for InputPin. This will be called whenever there is a raising edge detected. 
static irqreturn_t gpio_irq_handler1(int irq,void *dev_id) 
{
 
	disable_irq(in[0]);
    gpio_set_value(out[0],1);
   
   // Stuff you want the module do when the interrupt handler is called   
   
	enable_irq(in[0]);
	printk("Interrupt handled\n");

	return IRQ_HANDLED;
}

static irqreturn_t gpio_irq_handler2(int irq,void *dev_id) 
{
 
	disable_irq(in[1]);
    gpio_set_value(out[1],1);
   
   // Stuff you want the module do when the interrupt handler is called   
   
	enable_irq(in[1]);
	printk("Interrupt handled\n");

	return IRQ_HANDLED;
}

static irqreturn_t gpio_irq_handler3(int irq,void *dev_id) 
{
 
	disable_irq(in[2]);
    gpio_set_value(out[2],1);
   
   // Stuff you want the module do when the interrupt handler is called   
   
	enable_irq(in[2]);
	printk("Interrupt handled\n");

	return IRQ_HANDLED;
}
static irqreturn_t gpio_irq_handler4(int irq,void *dev_id) 
{
 
	disable_irq(in[3]);
    gpio_set_value(out[3],1);
   
   // Stuff you want the module do when the interrupt handler is called   
   
	enable_irq(in[3]);
	printk("Interrupt handled\n");

	return IRQ_HANDLED;
}
static irqreturn_t gpio_irq_handler5(int irq,void *dev_id) 
{
 
	disable_irq(in[4]);
	for(int i;i<4;i++)
	{
    	gpio_set_value(out[i],0);
	}
   // Stuff you want the module do when the interrupt handler is called   
   
	enable_irq(in[4]);
	printk("Interrupt handled\n");

	return IRQ_HANDLED;
}



/*
** Module Init function
*/ 
int init_module()   // Call the default name
{
	for(int i=0;i<5;i++)
{
		if(!gpio_is_valid(in[i]))
		{
			 printk(KERN_ERR "Failed to valid GPIO %d\n", in[i]);
        	return -1;
		}

		if (gpio_request(in[i], "Input Pin")) {
        	printk(KERN_ERR "Failed to request GPIO %d\n", in[i]);
       		return -1;
  		}

		if(gpio_direction_input(in[i])){
    		printk(KERN_ERR " Failed to set GPIO %d as Input\n", in[i]);
    		return -1;
		}
		GPIO_irq[i] = gpio_to_irq(in[i]);				//Get the IRQ number for our GPIO

}


		for(int i=0;i<4;i++)
{
		
		if(!gpio_is_valid(out[i]))
		{
			 printk(KERN_ERR "Failed to valid GPIO %d\n", out[i]);
        	return -1;
		}

		if (gpio_request(out[i], "output Pin")) {
        	printk(KERN_ERR "Failed to request GPIO for Output%d\n", out[i]);
        	return -1;
   		 }

		if(gpio_direction_output(out[i], 0))
		{
    		printk(KERN_ERR " Failed to set GPIO %d as output\n", out[i]);
    		return -1;
		}


}
	
    // Request the interrupt / attach handler
 	//Enable (Async) Rising Edge detection
	//The Fourth argument string can be different (you give the name)
	//The last argument is a variable needed to identify the handler, but can be set to NULL
	
	
	if (request_irq(GPIO_irq[0],(void *)gpio_irq_handler1, IRQF_TRIGGER_RISING,"Button Interrupt", NULL)) {                    //device id for shared IRQ
	pr_err("Cannot register the IRQ ");
	gpio_free(in[0]);
	}

	if (request_irq(GPIO_irq[1],(void *)gpio_irq_handler2, IRQF_TRIGGER_RISING,"Button Interrupt", NULL)) {                    //device id for shared IRQ
	pr_err("Cannot register the IRQ ");
	gpio_free(in[1]);
	}

	if (request_irq(GPIO_irq[2],(void *)gpio_irq_handler3, IRQF_TRIGGER_RISING,"Button Interrupt", NULL)) {                    //device id for shared IRQ
	pr_err("Cannot register the IRQ ");
	gpio_free(in[2]);
	}

	if (request_irq(GPIO_irq[3],(void *)gpio_irq_handler4, IRQF_TRIGGER_RISING,"Button Interrupt", NULL)) {                    //device id for shared IRQ
	pr_err("Cannot register the IRQ ");
	gpio_free(in[3]);
	}

	if (request_irq(GPIO_irq[4],(void *)gpio_irq_handler5, IRQF_TRIGGER_RISING,"Button Interrupt", NULL)) {                    //device id for shared IRQ
	pr_err("Cannot register the IRQ ");
	gpio_free(in[4]);
	}


	pr_info("Module Inserted!!!\n");
	return 0;

}

/*
** Module exit function
*/
void cleanup_module() 
{

	// ------
	// Remove the interrupt handler; you need to provide the same identifier
	for(int i=0;i<5;i++)
	{
		free_irq(GPIO_irq[i],NULL);
	}
	
	// Free the Pins
	for(int i=0;i<5;i++)
	{
		gpio_free(in[i]);
	}

	for(int i=0;i<4;i++)
	{	
		gpio_free(out[i]);
	}

	printk(KERN_INFO "*************Module Removed**********\n");
}
 

 


